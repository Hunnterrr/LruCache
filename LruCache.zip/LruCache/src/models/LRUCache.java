package models;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import static constants.CacheConstants.DEFAULT_LRU_CACHE_SIZE;

public class LRUCache<Key, Value> extends Cache<Key, Value> {

    private Integer capacity = DEFAULT_LRU_CACHE_SIZE;
    private Map<Key, Value> dataMap = new ConcurrentHashMap<>();
    private Deque<Key> orderedKeyList = new ArrayDeque<>();

    @Override
    public synchronized void setCapacity(Integer capacity) {
        this.capacity = capacity;
    }

    @Override
    public synchronized void put(Key key, Value value) {
        if(dataMap.containsKey(key)) {
            orderedKeyList.remove(key);
            orderedKeyList.addFirst(key);
            return;
        }
        if(dataMap.size() == capacity) {
            Key removedKey = orderedKeyList.removeLast();
            dataMap.remove(removedKey);
        }

        orderedKeyList.addFirst(key);
        dataMap.put(key, value);
    }

    @Override
    public Value get(Key key) {
        if(!orderedKeyList.contains(key)) {
            return null;
        }

        orderedKeyList.remove(key);
        orderedKeyList.addFirst(key);
        return dataMap.get(key);
    }
}
