package models;

public abstract class Cache<Key, Value> {

    public abstract void setCapacity(Integer capacity);

    public abstract void put(Key key, Value value);

    public abstract Value get(Key key);
}
