package models;

public class Collection<Key, Value> {
    private String name;
    private Cache<Key, Value> cache;

    public Collection(String name, Cache<Key, Value> cache) {
        this.name = name;
        this.cache = cache;
    }

    public String getName() {
        return name;
    }

    public Cache<Key, Value> getCache() {
        return cache;
    }
}
