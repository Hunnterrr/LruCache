import models.Cache;
import models.Collection;
import models.LRUCache;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class CacheStore {
    private Map<String, Cache> cacheMap = new ConcurrentHashMap<>();
    private static CacheStore cacheStore;

    public static synchronized CacheStore getInstance() {
        if(cacheStore == null) {
            cacheStore = new CacheStore();
        }
        return cacheStore;
    }

    public void addCollection(Collection collection) {
        cacheMap.putIfAbsent(collection.getName(), collection.getCache());
    }

    public void updateCapacity(String collectionName, Integer capacity) throws Exception {
        if(!cacheMap.containsKey(collectionName)) {
            throw new Exception("Invalid Collection");
        }
        cacheMap.get(collectionName).setCapacity(capacity);
    }

    public <Key, Value> void addData(String collectionId, Key key, Value value) throws Exception {
        if(!cacheMap.containsKey(collectionId)) {
            throw new Exception("Invalid Collection");
        }
        cacheMap.get(collectionId).put(key, value);
    }

    public <Key, Value> Value getData(String collectionId, Key key) throws Exception {
        if(!cacheMap.containsKey(collectionId)) {
            throw new Exception("Invalid Collection");
        }
        return (Value) cacheMap.get(collectionId).get(key);
    }
}
