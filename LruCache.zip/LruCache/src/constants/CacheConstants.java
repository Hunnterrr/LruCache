package constants;

public class CacheConstants {
    public static Integer DEFAULT_LRU_CACHE_SIZE = 5;
}
