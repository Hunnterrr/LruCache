import models.Collection;
import models.LRUCache;

public class CacheDemo {
    public static void main(String[] args) throws Exception {
        CacheStore cacheStore = CacheStore.getInstance();
        String collection1 = "collection1";
        cacheStore.addCollection(new Collection(collection1, new LRUCache<Integer, String>()));

        cacheStore.addData(collection1, 1, "hello");
        cacheStore.addData(collection1, 2, "world");
        System.out.println(cacheStore.getData(collection1, 2).toString());
        System.out.println("Hello world");
    }
}
